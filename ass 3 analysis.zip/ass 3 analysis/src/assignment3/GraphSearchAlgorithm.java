package assignment3;

import java.util.*;

public class GraphSearchAlgorithm {

    private static Map<Integer, List<Integer>> graph;

    public static void main(String[] args) {
        
        graph = new HashMap<>();
        graph.put(1, Arrays.asList(3, 4));
        graph.put(2, Arrays.asList(1, 3));
        graph.put(3, Collections.singletonList(4));
        graph.put(4, Arrays.asList(1, 2));

        System.out.println("Depth-First Search:");
        dfs(1);
        System.out.println("\nBreadth-First Search:");
        bfs(1);

        System.out.println("\nCycles in the graph:");
        findCycles();

        System.out.println("\nIs the graph bipartite? " + isBipartite());
    }

    private static void dfs(int start) {
        Set<Integer> visited = new HashSet<>();
        dfsRecursive(start, visited);
    }

    private static void dfsRecursive(int node, Set<Integer> visited) {
        if (visited.contains(node)) {
            return;
        }

        System.out.print(node + " ");
        visited.add(node);

        for (int neighbor : graph.getOrDefault(node, Collections.emptyList())) {
            dfsRecursive(neighbor, visited);
        }
    }

    private static void bfs(int start) {
        Queue<Integer> queue = new LinkedList<>();
        Set<Integer> visited = new HashSet<>();

        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            int node = queue.poll();
            System.out.print(node + " ");

            for (int neighbor : graph.getOrDefault(node, Collections.emptyList())) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                }
            }
        }
    }

    private static void findCycles() {
        Set<Integer> visited = new HashSet<>();
        for (int node : graph.keySet()) {
            if (!visited.contains(node)) {
                List<Integer> path = new ArrayList<>();
                if (dfsForCycle(node, visited, path, -1)) {
                    printCycle(path);
                }
            }
        }
    }

    private static boolean dfsForCycle(int node, Set<Integer> visited, List<Integer> path, int parent) {
        visited.add(node);
        path.add(node);

        for (int neighbor : graph.getOrDefault(node, Collections.emptyList())) {
            if (!visited.contains(neighbor)) {
                if (dfsForCycle(neighbor, visited, path, node)) {
                    return true;
                }
            } else if (neighbor != parent) {
                
                path.add(neighbor);
                return true;
            }
        }

        path.remove(path.size() - 1); 
        return false;
    }

    private static void printCycle(List<Integer> cycle) {
        for (int node : cycle) {
            System.out.print(node + " ");
        }
        System.out.println();
    }

    private static boolean isBipartite() {
        Set<Integer> visited = new HashSet<>();
        Map<Integer, Integer> colorMap = new HashMap<>();

        for (int node : graph.keySet()) {
            if (!visited.contains(node)) {
                if (!bfsForBipartite(node, visited, colorMap)) {
                    return false;
                }
            }
        }

        return true;
    }

    private static boolean bfsForBipartite(int start, Set<Integer> visited, Map<Integer, Integer> colorMap) {
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);
        visited.add(start);
        colorMap.put(start, 0);

        while (!queue.isEmpty()) {
            int node = queue.poll();

            for (int neighbor : graph.getOrDefault(node, Collections.emptyList())) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                    colorMap.put(neighbor, 1 - colorMap.get(node));
                } else if (colorMap.get(neighbor).equals(colorMap.get(node))) {
                    return false; 
                }
            }
        }

        return true;
    }
}

